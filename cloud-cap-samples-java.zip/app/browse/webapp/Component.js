sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("bookshop.Component", {
    metadata:{ manifest:'json' }
}))
