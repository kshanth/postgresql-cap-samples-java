sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("reviews.Component", {
    metadata:{ manifest:'json' }
}))
