sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("notes.Component", {
    metadata:{ manifest:'json' }
}))
