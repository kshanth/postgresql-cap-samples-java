sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("addresses.Component", {
    metadata:{ manifest:'json' }
}))
