sap.ui.define(["sap/fe/core/AppComponent"], ac => ac.extend("admin.Component", {
    metadata:{ manifest:'json' }
}))
