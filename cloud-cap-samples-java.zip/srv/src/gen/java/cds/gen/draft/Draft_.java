package cds.gen.draft;

import com.sap.cds.ql.CdsName;
import java.lang.Class;
import java.lang.String;

@CdsName("DRAFT")
public interface Draft_ {
  String CDS_NAME = "DRAFT";

  Class<DraftAdministrativeData_> DRAFT_ADMINISTRATIVE_DATA = DraftAdministrativeData_.class;
}
